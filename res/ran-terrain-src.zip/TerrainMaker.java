import java.awt.image.BufferedImage;
import java.util.Random;

public class TerrainMaker {

	private final int tSize;
	private final BufferedImage image;
	private final Random ran;
	
	public TerrainMaker(final BufferedImage image) {
		
		this.image = image;
		tSize = image.getWidth() * image.getHeight();
		ran = new Random();
	}
	
	public void generate() {
		if(image != null) {
			final byte[][] count = new byte[image.getHeight()][image.getWidth()];
			final int coverage = (int) (tSize * (0.7f + (ran.nextInt(101) * 0.002f)));
			int pCovered = 0,x = 0,y = 0;
			byte max = 0;
			float ccThresh = 0.0f;
			float ccVal = 0.0f;
			int dirMax = 0;
			final int[] dir = new int[4];
			int cDir;
			while(pCovered < coverage) {
				ccVal += ran.nextFloat();
				if(ccVal > ccThresh) {
					x = ran.nextInt(image.getWidth());
					y = ran.nextInt(image.getHeight());
					ccVal = 0.0f;
					ccThresh = ran.nextFloat() * 100.5f;
					dirMax = 32;
					for(int i=0;i<dir.length;i++) {
						dir[i] = 8 * (i + 1);
					}
				}else {
					cDir = ran.nextInt(dirMax);
					for(int i=0;i<dir.length;i++) {
						if(cDir < dir[i]) {
							switch(i) {
							
							case 0:
								x++;
								if(x >= image.getWidth()) {
									ccVal = ccThresh;
								}
								break;
								
							case 1:
								x--;
								if(x < 0) {
									ccVal = ccThresh;
								}
								break;
								
							case 2:
								y++;
								if(y >= image.getHeight()) {
									ccVal = ccThresh;
								}
								break;
								
							default:
								y--;
								if(y < 0) {
									ccVal = ccThresh;
								}
								break;
							}
							break;
						}
					}
				}
				if(x + 1 < image.getWidth() && y < image.getHeight() && y >= 0) {
					if(count[y][x+1] == 0) {
						pCovered++;
					}
					count[y][x+1]++;
					if(count[y][x+1] > max) {
						max = count[y][x+1];
					}
				}
				if(x - 1 >= 0 && y < image.getHeight() && y >= 0) {
					if(count[y][x-1] == 0) {
						pCovered++;
					}
					count[y][x-1]++;
					if(count[y][x-1] > max) {
						max = count[y][x-1];
					}
				}
				if(y + 1 < image.getHeight() && x >= 0 && x < image.getWidth()) {
					if(count[y+1][x] == 0) {
						pCovered++;
					}
					count[y+1][x]++;
					if(count[y+1][x] > max) {
						max = count[y+1][x];
					}
				}
				if(y - 1 >= 0 && x >= 0 && x < image.getWidth()) {
					if(count[y-1][x] == 0) {
						pCovered++;
					}
					count[y-1][x]++;
					if(count[y-1][x] > max) {
						max = count[y-1][x];
					}
				}
			}
			for(int i=0;i<count.length;i++) {
				for(int j=0;j<count[i].length;j++) {
					int col = 0xFF000000;
					if(count[i][j] < 1) {
						col |= 0x0000FF;
					}else {
						int r = clamp((int) (255.0f * (float) count[i][j] / (float) max));
						int g = clamp(r/2);
						col |= (r << 16);
						col |= (g << 8);
					}
					image.setRGB(j, i, col);
				}
			}
		}
	}
	
	private int clamp(final int col) {
		
		return (col < 0) ? 0 : (col > 255) ? 255 : col;
	}
}
