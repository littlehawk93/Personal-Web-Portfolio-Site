import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import javax.swing.JButton;
import javax.swing.JFrame;

public class GUI {

	public static final JFrame window = new JFrame(" Terrain Generator ");
	public static final JButton button = new JButton(" Generate ");
	
	public static BufferedImage image;
	public static ImagePanel panel;
	
	public static void main(final String[] args) {
		
		image = new BufferedImage(256,256,BufferedImage.TYPE_4BYTE_ABGR);
		panel = new ImagePanel();
		panel.image = image;
		final TerrainMaker terMaker = new TerrainMaker(image);
		terMaker.generate();
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				terMaker.generate();
				panel.repaint();
			}
		});
		window.setLayout(new BorderLayout());
		window.add(panel,BorderLayout.CENTER);
		window.add(button,BorderLayout.NORTH);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(500,500);
		window.setResizable(false);
		window.setVisible(true);
	}
}
